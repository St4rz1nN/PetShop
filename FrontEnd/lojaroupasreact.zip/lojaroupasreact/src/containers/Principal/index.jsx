import Header from '../../components/Header/index.jsx'
import { Container } from './styles.js'

function Principal(){
    
    return (
        <Container>
            <Header
                titleName="LOJA ROUPAS"
            />
        </Container>
    )
}

export default Principal;